import React from 'react';

const Navbar = () => {
  const navItems = [
    { id: 'introducao', label: 'Introdução' },
    { id: 'analise-site', label: 'Análise do Site' },
    { id: 'benchmarks', label: 'Benchmarks' },
    { id: 'estrategia-google', label: 'Google Ads' },
    { id: 'estrategia-meta', label: 'Meta Ads' },
    { id: 'estrutura-orcamento', label: 'Orçamento' },
    { id: 'projecoes', label: 'Projeções' },
    { id: 'conclusao', label: 'Conclusão' },
    { id: 'referencias', label: 'Referências' },
  ];

  return (
    <nav className="bg-slate-700 p-4 sticky top-0 z-50">
      <ul className="flex flex-wrap justify-center space-x-4">
        {navItems.map((item) => (
          <li key={item.id} className="my-1">
            <a 
              href={`#${item.id}`} 
              className="text-white hover:text-teal-300 transition-colors duration-300 px-3 py-2 rounded-md text-sm font-medium"
            >
              {item.label}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navbar;
