import React from 'react';

const Header = () => {
  return (
    <header className="bg-slate-800 text-white py-8 text-center">
      <h1 className="text-4xl font-bold font-montserrat">Proposta Estratégica de Tráfego Pago</h1>
      <p className="text-lg mt-2 font-lato">Instituto Andreia Costa (via SENVIA)</p>
    </header>
  );
};

export default Header;
