import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-slate-800 text-white py-8 text-center mt-12">
      <p className="font-lato">&copy; 2025 SENVIA & Manus AI. Proposta elaborada para o Instituto Andreia Costa.</p>
    </footer>
  );
};

export default Footer;
