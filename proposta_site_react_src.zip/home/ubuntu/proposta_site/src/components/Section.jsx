import React from 'react';

const Section = ({ id, title, children }) => {
  return (
    <section id={id} className="py-8 px-4 md:px-8 lg:px-12 bg-white shadow-lg rounded-lg mb-12">
      <h2 className="text-3xl font-bold text-slate-800 font-montserrat mb-6 border-b-2 border-teal-400 pb-2">{title}</h2>
      <div className="prose prose-lg max-w-none text-slate-700 font-lato">
        {children}
      </div>
    </section>
  );
};

export default Section;
