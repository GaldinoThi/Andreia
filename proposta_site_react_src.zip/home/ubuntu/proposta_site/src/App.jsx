import React from 'react';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Footer from './components/Footer';
import Section from './components/Section';

// Import Tailwind CSS styles
import './index.css';

function App() {
  return (
    <div className="bg-slate-100 min-h-screen flex flex-col">
      <Header />
      <Navbar />
      <main className="container mx-auto px-4 py-8 flex-grow">
        <Section id="introducao" title="Introdução e Objetivos da Proposta">
          <p>Esta proposta estratégica foi meticulosamente elaborada com o intuito de fornecer ao Instituto Andreia Costa, por intermédio da SENVIA, um plano de ação detalhado e robusto para a implementação de campanhas de tráfego pago nas plataformas Google Ads e Meta Ads. Compreendendo a importância deste projeto como o primeiro cliente de gestão de tráfego da SENVIA, dedicamo-nos a construir uma estratégia que não apenas atenda, mas exceda as expectativas em termos de profundidade analítica, detalhamento tático e projeções realistas.</p>
          <p>O principal objetivo desta iniciativa é impulsionar a captação de clientes para os serviços de Constelação Familiar oferecidos pelo Instituto, otimizando o orçamento disponível de 300 euros mensais para alcançar resultados tangíveis e mensuráveis. Ao longo deste documento, exploraremos a análise do panorama digital do Instituto, as tendências de mercado, as estratégias específicas para cada plataforma de anúncio, a estrutura de campanhas, a alocação orçamentária e as métricas de desempenho esperadas, tudo consolidado de forma a guiar a SENVIA rumo ao sucesso nesta empreitada.</p>
        </Section>

        <Section id="analise-site" title="Análise do Panorama Digital: O Website do Instituto Andreia Costa">
          <p>Uma análise aprofundada do website do Instituto Andreia Costa, acessível em <a href="https://institutoandreiacosta.pt/pc-constelacao-familiar-google/" target="_blank" rel="noopener noreferrer" className="text-teal-500 hover:text-teal-700">https://institutoandreiacosta.pt/pc-constelacao-familiar-google/</a>, foi conduzida em 14 de Maio de 2025 para embasar as estratégias de tráfego pago. Esta investigação revelou aspetos cruciais sobre a oferta de serviços, o público-alvo e a atual presença online do Instituto.</p>
          <p>O serviço central promovido é a <strong>Constelação Familiar</strong>, apresentada como uma abordagem terapêutica inovadora destinada a desvendar e solucionar dinâmicas ocultas e padrões comportamentais herdados que exercem influência negativa na vida dos indivíduos. A figura central desta prática é a terapeuta Andreia Costa, vinculada ao Instituto Andreia Costa - Desenvolvimento Pessoal...</p>
          {/* Rest of the Analise do Site content */}
          <p>Em suma, o website do Instituto Andreia Costa constitui uma base sólida para o lançamento de campanhas de tráfego pago, com potencial de otimização para maximizar a qualificação de leads e o acompanhamento de conversões.</p>
        </Section>

        <Section id="benchmarks" title="Benchmarks e Tendências de Anúncios">
          <p>Uma investigação aprofundada sobre os benchmarks e tendências de anúncios para o nicho de Constelação Familiar e terapias alternativas, conduzida em 14 de Maio de 2025, revelou um panorama dinâmico e com particularidades importantes para a elaboração de estratégias de tráfego pago eficazes...</p>
          {/* Rest of the Benchmarks content */}
          <p>Os desafios específicos para um orçamento de 300 euros incluem o alcance limitado e a necessidade de foco e otimização constante, sendo irrealista esperar um volume massivo de clientes no primeiro mês; o objetivo principal será validar as estratégias e gerar os primeiros leads qualificados.</p>
        </Section>

        <Section id="estrategia-google" title="Estratégia Detalhada para Google Ads">
          <p>Para o Google Ads, a estratégia delineada em 14 de Maio de 2025, fundamentada na análise do site e na pesquisa de benchmarks, visa primordialmente gerar leads qualificados para o serviço de Constelação Familiar...</p>
          {/* Rest of the Google Ads Strategy content */}
          <p>Esta abordagem inicial visa maximizar o retorno sobre o investimento limitado, focando em utilizadores com alta intenção e permitindo otimizações baseadas em dados concretos.</p>
        </Section>

        <Section id="estrategia-meta" title="Estratégia Detalhada para Meta Ads">
          <p>A estratégia para Meta Ads (Facebook e Instagram), elaborada em 14 de Maio de 2025 e alinhada com as análises prévias, visa primariamente gerar leads qualificados para o serviço de Constelação Familiar...</p>
          {/* Rest of the Meta Ads Strategy content */}
          <p>Esta estratégia visa um equilíbrio entre geração de leads e construção de marca, com otimização constante baseada em dados.</p>
        </Section>

        <Section id="estrutura-orcamento" title="Estrutura de Campanhas e Distribuição de Orçamento">
          <p>A definição da estrutura de campanhas e a criteriosa distribuição do orçamento mensal de 300 euros são pilares fundamentais para o sucesso da estratégia de tráfego pago do Instituto Andreia Costa...</p>
          <img src="/images/grafico_distribuicao_orcamento.png" alt="Gráfico de Distribuição Proposta do Orçamento Mensal" className="max-w-full h-auto mx-auto my-4 border border-gray-300 rounded p-1" />
          <p className="text-center italic text-sm">Gráfico 1: Ilustração da distribuição percentual do orçamento de 300 euros entre Google Ads e Meta Ads.</p>
        </Section>

        <Section id="projecoes" title="Projeção de Métricas e Expectativas de Resultado">
          <p>Estabelecer projeções de métricas e expectativas de resultado realistas é um componente vital desta proposta estratégica, fornecendo ao Instituto Andreia Costa uma visão clara do que pode ser alcançado com o orçamento mensal de 300 euros...</p>
          <img src="/images/grafico_projecao_leads.png" alt="Gráfico de Projeção Estimada de Leads Mensais" className="max-w-full h-auto mx-auto my-4 border border-gray-300 rounded p-1" />
          <p className="text-center italic text-sm">Gráfico 2: Ilustração da projeção estimada de leads mensais, por plataforma (Google Ads e Meta Ads), com indicação de intervalo mínimo e máximo.</p>
        </Section>

        <Section id="conclusao" title="Conclusão e Próximos Passos">
          <p>Esta proposta estratégica detalhada para o Instituto Andreia Costa representa um roteiro abrangente e fundamentado para iniciar uma jornada de sucesso no tráfego pago...</p>
          <p>A SENVIA, com este plano em mãos, está preparada para demonstrar o valor da gestão de tráfego profissional e entregar resultados concretos para o Instituto Andreia Costa, marcando o início de uma parceria de sucesso.</p>
        </Section>

        <Section id="referencias" title="Materiais de Referência e Anexos">
          <p>Os seguintes documentos foram elaborados como parte desta análise e estratégia, servindo de base para as recomendações apresentadas (os arquivos .md originais podem ser consultados para maior detalhe):</p>
          <ul className="list-disc list-inside ml-4">
            <li>Análise do site do Instituto Andreia Costa.</li>
            <li>Pesquisa sobre benchmarks e tendências de anúncios para o nicho.</li>
            <li>Estratégia específica para as campanhas no Google Ads.</li>
            <li>Estratégia específica para as campanhas no Meta Ads.</li>
            <li>Estrutura de campanhas e a distribuição do orçamento.</li>
            <li>Projeção detalhada de métricas e expectativas de resultado.</li>
          </ul>
          <p>Os gráficos apresentados neste site (Distribuição do Orçamento e Projeção de Leads) também fazem parte dos materiais de apoio.</p>
        </Section>

      </main>
      <Footer />
    </div>
  );
}

export default App;

